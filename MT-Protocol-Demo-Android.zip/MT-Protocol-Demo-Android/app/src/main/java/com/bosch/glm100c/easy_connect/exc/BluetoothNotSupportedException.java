package com.bosch.glm100c.easy_connect.exc;

public class BluetoothNotSupportedException extends BluetoothException {
	private static final long serialVersionUID = 1L;
}
