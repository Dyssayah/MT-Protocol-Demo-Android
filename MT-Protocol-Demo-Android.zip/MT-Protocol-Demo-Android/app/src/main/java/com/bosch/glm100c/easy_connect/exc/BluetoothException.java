package com.bosch.glm100c.easy_connect.exc;

public class BluetoothException extends Exception {
	private static final long serialVersionUID = 1L;
}
